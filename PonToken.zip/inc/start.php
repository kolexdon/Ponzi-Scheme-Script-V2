<?php
//Ponzi Script
//BY FLASHWEBTECH INC
//ADESANOYE ADELEYE BENJAMIN 
//BennySWAG DACYBERPOWER
//09022165970 or 08110446469
// flashwebtech@gmail.com
//Dacyberpower Ltd
define('FLASHWEBTECHINC',1);
define('ADESFLASH',true);
defined('ADESFLASH') or die ('Access Forbidden!');
?>