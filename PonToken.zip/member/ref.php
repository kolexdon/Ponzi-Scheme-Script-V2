<?php
//Ponzi Script
//BY FLASHWEBTECH INC
//ADESANOYE ADELEYE BENJAMIN 
//BennySWAG DACYBERPOWER
//09022165970 or 08110446469
// flashwebtech@gmail.com
//Dacyberpower Ltd
include '../inc/header.php';
defined('ADESFLASH') or exit('404 Access Blocked!');
if(FLASHWEBTECHINC !== 1) {
	echo 'No Direct Script Access!';
	exit('Access Forbiden!');
}
$usernm = $_GET['ref'];
$ckdu = $flash->prepare("SELECT * FROM `user` WHERE `username`=:un");
$ckdu->bindParam(':un',$usernm);
$ckdu->execute();
if($ckdu->rowCount() > 0){
$_SESSION['ref'] = $_GET['ref'];
}
header('Location: '.$set['url'].'/member/register');
exit;
?>