<start requirement>
Server Requirement
mysql_prefix();
eg: mysql_connect();
mysql_select_db();
php 5.x .
</end requirement>
<start forbidden>
Server Forbidden.
php 7.x .
</end Forbidden>

<start making admin function>
Login as admin
Now Click on Admin Panel
Then you will see 
"Site Settings" Click it.
U will see automerge 
put it to "Yes" for automerge
And autopurge to "Yes" for autopurge
And Admin Merge to "Yes" if you want only admin to get paid
But if Admin Merge is "Yes" no user can GH only the admin
</end making admin function>

<start installation>
ReadMe By FlashWebTech Inc
WelCome To Ponzi Script By BennySwag  DacyberPower The C.E.O of FlashWebTech Inc

To Install This Script Read Bellow


Step1: First Check on Folder /install
Download of Copy /install/ponzi.sql  
And Upload to PhpMyAdmin

Step2: Open Folder /inc/config.php
fill your database details thier

Step3: Add Admin 
Visit http://yourwebsite.com/install/setting.php
Visit http://yourwebsite.com/install/admin.php
Fill Form And Register As Admin

Step4: Protect Hacking
Rename or Delete /install/       folder  delete recommended.
Rename /install/admin.php to something else we recommend to Delete it
 Rename Admin File Or Delete Because of Hacker
 
 Step5: Login to Your Account To SetUp all Controls
 Visit http://yourwebsite.com/member/login
 After Login
 Visit http://yourwebsite.com/admin/setting.php 
 to set all comulsory settings
 
 Finally: Launch Your Punzi Site And access Admin Panel 
 By Scrolling Down To your Website Footer..
 Any Error Call : 09022165970 , 08110446469 
 
 We Are the FlashWebTechian We Rule Over Code!.........
 
 Make Sure your remove this ReadMe.txt After you have successfully installed this script...
</end installation>